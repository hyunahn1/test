cat | sed 's/\"/\\\"/g'
